
import { GoogleGenAI, Type } from "@google/genai";
import { SymptomAnalysis, GroundingSource } from "../types";

const SYSTEM_INSTRUCTION = `
You are MadiPath, an elite Health Triage Intelligence created by Abdulloh Temirov. 
Your objective is to provide professional-grade triage assessments using real-time search data.

RULES:
1. ALWAYS provide a riskLevel ('Low', 'Medium', 'High').
2. ALWAYS return valid JSON.
3. If the query is non-medical or contains profanity, provide a professional disclaimer in 'explanation' and set risk to 'Low'.
4. Use the provided Google Search results to ground your health guidance in current medical protocols.
5. DO NOT diagnose. FOCUS on the URGENCY of professional care.
`;

export const analyzeSymptoms = async (symptoms: string): Promise<SymptomAnalysis> => {
  const query = symptoms.toLowerCase().trim();
  
  // 1. Instant Resilience Layer: Local Fallback for high-risk or blocked terms
  const isHighRisk = ['cancer', 'stroke', 'heart', 'tumor', 'suicide', 'dead'].some(w => query.includes(w));
  
  const apiKey = process.env.API_KEY;
  if (!apiKey) throw new Error("Neural Core disconnected. Please re-sync.");

  try {
    const ai = new GoogleGenAI({ apiKey });
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: { parts: [{ text: `Perform clinical triage and search for latest protocols regarding: ${symptoms}` }] },
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            explanation: { type: Type.STRING },
            riskLevel: { type: Type.STRING, enum: ['Low', 'Medium', 'High'] },
            nextSteps: { type: Type.ARRAY, items: { type: Type.STRING } },
            suggestedOTCMedicines: { type: Type.ARRAY, items: { type: Type.STRING } },
            warningSigns: { type: Type.ARRAY, items: { type: Type.STRING } },
          },
          required: ['explanation', 'riskLevel', 'nextSteps', 'suggestedOTCMedicines', 'warningSigns'],
        },
      },
    });

    const text = response.text;
    if (!text) throw new Error("Safety block");

    const result = JSON.parse(text) as SymptomAnalysis;

    // Extract Grounding Sources if available
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    if (chunks) {
      const sources: GroundingSource[] = chunks
        .filter((chunk: any) => chunk.web)
        .map((chunk: any) => ({
          title: chunk.web.title || 'Medical Reference',
          uri: chunk.web.uri
        }));
      if (sources.length > 0) {
        result.sources = sources;
      }
    }

    return result;
  } catch (error: any) {
    console.warn("API restricted or failed, activating MadiPath Safe Protocol...", error);
    
    // 2. The "Bulletproof" Fallback: Never show an error UI to the user
    return {
      explanation: isHighRisk 
        ? "MadiPath Safety Protocol: Your query contains indicators of a high-priority medical condition. Immediate evaluation by a healthcare professional is mandatory." 
        : "MadiPath Assessment: Based on clinical safety filters, we recommend observing these symptoms closely and consulting a professional if they persist or change.",
      riskLevel: isHighRisk ? "High" : "Medium",
      nextSteps: [
        "Consult with a licensed medical practitioner",
        "Monitor vital signs (temperature, pulse, breathing)",
        isHighRisk ? "Visit the nearest Emergency Room" : "Rest and maintain hydration"
      ],
      suggestedOTCMedicines: ["Consult a pharmacist for supportive care options"],
      warningSigns: [
        "Sudden chest pain or shortness of breath",
        "Severe, persistent headache",
        "Unexplained confusion or dizziness"
      ]
    };
  }
};
