
import React from 'react';
import { SymptomAnalysis } from '../types';

interface AnalysisResultProps {
  data: SymptomAnalysis;
}

export const AnalysisResult: React.FC<AnalysisResultProps> = ({ data }) => {
  const getRiskStyles = (level: string) => {
    switch (level) {
      case 'High':
        return 'bg-red-500/10 text-red-400 border-red-500/30';
      case 'Medium':
        return 'bg-amber-500/10 text-amber-400 border-amber-500/30';
      case 'Low':
        return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30';
      default:
        return 'bg-slate-500/10 text-slate-400 border-slate-500/30';
    }
  };

  const getRiskBadge = (level: string) => {
    switch (level) {
      case 'High': return 'CRITICAL: HIGH RISK';
      case 'Medium': return 'CAUTION: MEDIUM RISK';
      case 'Low': return 'STABLE: LOW RISK';
      default: return level;
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-10 duration-700">
      <div className={`p-10 rounded-[3rem] border-2 shadow-2xl backdrop-blur-xl ${getRiskStyles(data.riskLevel)}`}>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-8">
          <div>
            <span className="text-[10px] font-black uppercase tracking-[0.4em] mb-4 block opacity-60">Intelligence Assessment</span>
            <h2 className="text-4xl font-black tracking-tighter">{getRiskBadge(data.riskLevel)}</h2>
          </div>
          {data.riskLevel === 'High' && (
            <button
              onClick={() => window.open('https://www.google.com/maps/search/nearby+hospital', '_blank')}
              className="px-8 py-5 bg-red-600 hover:bg-red-500 text-white font-black rounded-2xl shadow-2xl shadow-red-500/30 transition-all flex items-center justify-center space-x-3 text-sm uppercase tracking-widest"
            >
              <span>Emergency Services</span>
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="glass-card p-10 rounded-[3rem]">
          <h3 className="font-black text-white text-lg mb-6 flex items-center uppercase tracking-widest">
            <span className="w-2 h-2 bg-blue-500 rounded-full mr-4 shadow-lg shadow-blue-500"></span>
            Neural Analysis
          </h3>
          <p className="text-slate-400 leading-relaxed font-bold italic">
            "{data.explanation}"
          </p>
        </div>

        <div className="glass-card p-10 rounded-[3rem]">
          <h3 className="font-black text-white text-lg mb-6 flex items-center uppercase tracking-widest">
            <span className="w-2 h-2 bg-emerald-500 rounded-full mr-4 shadow-lg shadow-emerald-500"></span>
            Protocol
          </h3>
          <ul className="space-y-4">
            {data.nextSteps.map((step, idx) => (
              <li key={idx} className="flex items-start text-sm text-slate-400 font-bold">
                <span className="text-emerald-500 mr-3 mt-1">✓</span>
                {step}
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="glass-card p-10 rounded-[3rem]">
          <h3 className="font-black text-white text-lg mb-6 flex items-center uppercase tracking-widest">
            <span className="w-2 h-2 bg-purple-500 rounded-full mr-4 shadow-lg shadow-purple-500"></span>
            Supportive Care
          </h3>
          <div className="flex flex-wrap gap-3 mb-6">
            {data.suggestedOTCMedicines.map((med, idx) => (
              <span key={idx} className="px-5 py-2 bg-purple-500/10 text-purple-400 text-[10px] font-black rounded-full border border-purple-500/20 uppercase tracking-widest">
                {med}
              </span>
            ))}
          </div>
          <p className="text-[10px] text-slate-500 font-bold italic">
            * Consult a pharmacist before use. Abdulloh Temirov / MadiPath.
          </p>
        </div>

        <div className="glass-card p-10 rounded-[3rem] border-red-500/10">
          <h3 className="font-black text-white text-lg mb-6 flex items-center uppercase tracking-widest">
            <span className="w-2 h-2 bg-red-500 rounded-full mr-4 shadow-lg shadow-red-500"></span>
            Warning Signs
          </h3>
          <ul className="space-y-4">
            {data.warningSigns.map((sign, idx) => (
              <li key={idx} className="flex items-start text-sm text-slate-400 font-bold">
                <span className="text-red-500 mr-3 mt-1">!</span>
                {sign}
              </li>
            ))}
          </ul>
        </div>
      </div>

      {data.sources && data.sources.length > 0 && (
        <div className="glass-card p-10 rounded-[3rem] border-blue-500/20">
          <h3 className="font-black text-white text-lg mb-6 flex items-center uppercase tracking-widest">
            <span className="w-2 h-2 bg-blue-400 rounded-full mr-4 shadow-lg shadow-blue-400"></span>
            Neural Grounding Sources
          </h3>
          <div className="flex flex-wrap gap-4">
            {data.sources.map((source, idx) => (
              <a 
                key={idx} 
                href={source.uri} 
                target="_blank" 
                rel="noopener noreferrer"
                className="px-6 py-3 bg-white/5 border border-white/10 hover:border-blue-500/40 text-[10px] text-blue-400 font-black rounded-2xl uppercase tracking-widest transition-all"
              >
                {source.title.length > 30 ? source.title.substring(0, 30) + '...' : source.title} ↗
              </a>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
