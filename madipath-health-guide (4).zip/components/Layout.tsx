import React, { useState } from 'react';

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [copied, setCopied] = useState(false);

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <div className="flex flex-col min-h-screen">
      {/* Global Safety Bar */}
      <div className="bg-blue-600/10 border-b border-white/5 py-1.5 text-center">
        <p className="text-[8px] font-black uppercase tracking-[0.5em] text-blue-400">
          Independent Startup Initiative • Founded by Abdulloh Temirov
        </p>
      </div>

      <nav className="sticky top-0 z-50 bg-slate-950/40 backdrop-blur-xl border-b border-white/5">
        <div className="max-w-7xl mx-auto px-8 h-20 flex items-center justify-between">
          <div className="flex items-center space-x-5">
            <div className="w-11 h-11 bg-blue-600 rounded-xl flex items-center justify-center shadow-2xl shadow-blue-500/20">
              <span className="text-white font-black text-2xl">M</span>
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-black text-white tracking-tighter uppercase leading-none">MadiPath</span>
              <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1">Health Intelligence</span>
            </div>
          </div>
          
          <button 
            onClick={handleShare}
            className={`text-[10px] font-black uppercase tracking-[0.2em] px-8 py-3 rounded-full transition-all border ${
              copied 
              ? 'bg-emerald-500 border-emerald-400 text-white' 
              : 'bg-white text-black border-white hover:bg-slate-200'
            }`}
          >
            {copied ? 'Link Copied' : 'Share Startup'}
          </button>
        </div>
      </nav>

      <main className="flex-grow">
        {children}
      </main>

      <footer className="bg-black text-white py-28 border-t border-white/5 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-8 relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-24 items-end mb-24">
            <div>
              <div className="flex items-center space-x-4 mb-8">
                <div className="w-9 h-9 bg-blue-600 rounded-lg flex items-center justify-center shadow-lg shadow-blue-500/10">
                  <span className="text-white font-bold text-base">M</span>
                </div>
                <span className="text-2xl font-black tracking-tighter uppercase">MadiPath</span>
              </div>
              <p className="text-slate-400 text-xl leading-relaxed max-w-sm font-medium">
                The future of human-centric public health guidance. An independent startup project.
              </p>
            </div>
            
            <div className="p-12 rounded-[3rem] border border-white/10 bg-white/5 backdrop-blur-3xl shadow-2xl">
              <p className="text-[10px] text-blue-400 font-black uppercase tracking-[0.4em] mb-4">Founder & Principal Creator</p>
              <h3 className="text-5xl font-black text-white tracking-tighter">Abdulloh Temirov</h3>
              <div className="h-1.5 w-16 bg-blue-600 mt-8 rounded-full"></div>
            </div>
          </div>
          
          <div className="pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="flex flex-col gap-2">
              <p className="text-[10px] text-slate-500 font-black uppercase tracking-[0.3em]">
                &copy; {new Date().getFullYear()} MadiPath Startup • Built for Global Safety
              </p>
              <p className="text-[9px] text-slate-600 font-bold max-w-lg">
                MadiPath does not provide medical diagnosis or treatment. This platform is for informational purposes only. Developed independently by Abdulloh Temirov.
              </p>
            </div>
            <div className="flex space-x-10 text-[10px] font-black uppercase tracking-[0.3em] text-slate-400">
              <a href="#" className="hover:text-blue-400 transition-colors">Ethics</a>
              <a href="#" className="hover:text-blue-400 transition-colors">Privacy</a>
              <a href="#" className="hover:text-blue-400 transition-colors">Safety</a>
            </div>
          </div>
        </div>
        {/* Abstract background glow */}
        <div className="absolute -bottom-40 -left-40 w-full h-full bg-blue-600/5 blur-[120px] rounded-full pointer-events-none"></div>
      </footer>
    </div>
  );
};