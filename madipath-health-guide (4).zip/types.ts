
export type RiskLevel = 'Low' | 'Medium' | 'High';

export interface GroundingSource {
  title: string;
  uri: string;
}

export interface SymptomAnalysis {
  explanation: string;
  riskLevel: RiskLevel;
  nextSteps: string[];
  suggestedOTCMedicines: string[];
  warningSigns: string[];
  sources?: GroundingSource[];
}

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}
