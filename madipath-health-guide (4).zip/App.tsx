
import React, { useState, useEffect } from 'react';
import { Layout } from './components/Layout';
import { AnalysisResult } from './components/AnalysisResult';
import { analyzeSymptoms } from './services/geminiService';
import { SymptomAnalysis } from './types';

declare global {
  interface AIStudio {
    hasSelectedApiKey: () => Promise<boolean>;
    openSelectKey: () => Promise<void>;
  }
  interface Window {
    // Correctly match the environment's declaration of aistudio as readonly to avoid TS errors
    readonly aistudio: AIStudio;
  }
}

const App: React.FC = () => {
  const [inputText, setInputText] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<SymptomAnalysis | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isConnected, setIsConnected] = useState<boolean | null>(null);

  useEffect(() => {
    checkConnection();
  }, []);

  const checkConnection = async () => {
    try {
      const hasKey = await window.aistudio.hasSelectedApiKey();
      setIsConnected(hasKey);
    } catch (e) {
      setIsConnected(false);
    }
  };

  const handleConnect = async () => {
    await window.aistudio.openSelectKey();
    setIsConnected(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const data = await analyzeSymptoms(inputText.trim());
      setResult(data);
    } catch (err: any) {
      console.error("App Error:", err);
      if (err.message?.includes("API_KEY") || err.message?.includes("not found")) {
        setIsConnected(false);
      }
      setError(err.message || "The medical engine is temporarily unavailable.");
    } finally {
      setLoading(false);
    }
  };

  if (isConnected === false) {
    return (
      <Layout>
        <div className="max-w-4xl mx-auto px-6 py-32 animate-slide-up">
          <div className="glass-card p-16 rounded-[4rem] border-blue-500/30 shadow-2xl text-center">
            <div className="w-24 h-24 bg-blue-600/10 rounded-full flex items-center justify-center mx-auto mb-10 border border-blue-500/20">
              <span className="text-4xl animate-pulse">🧠</span>
            </div>
            <h2 className="text-4xl font-black text-white uppercase tracking-tighter mb-6">Neural Link Required</h2>
            <p className="text-slate-400 text-lg mb-12">Connect the MadiPath Engine to begin triage assessments.</p>
            <button 
              onClick={handleConnect}
              className="px-12 py-6 bg-blue-600 hover:bg-blue-500 text-white font-black rounded-3xl transition-all shadow-xl shadow-blue-600/20 uppercase tracking-widest"
            >
              Sync Engine
            </button>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="max-w-6xl mx-auto px-8 pt-20 pb-40 animate-slide-up">
        {/* Startup Branding */}
        <div className="text-center mb-24 relative">
          <div className="absolute top-0 right-0 flex items-center space-x-2 bg-white/5 px-4 py-2 rounded-full border border-white/10">
            <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
            <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Core Active</span>
          </div>

          <div className="inline-flex items-center space-x-4 px-5 py-2 mb-8 bg-blue-600/5 border border-blue-500/20 rounded-full">
            <span className="text-[10px] font-black text-blue-400 uppercase tracking-[0.4em]">Health Intelligence</span>
          </div>
          
          <h1 className="text-6xl md:text-[7rem] font-black text-white mb-8 tracking-tighter leading-none text-glow">
            Smart Triage.<br/>
            <span className="text-blue-600">Total Safety.</span>
          </h1>
          
          <p className="text-xl text-slate-400 font-medium max-w-2xl mx-auto">
            MadiPath by <span className="text-white">Abdulloh Temirov</span> providing professional-grade symptom guidance for a safer world.
          </p>
        </div>

        {/* Search Bar */}
        <div className="max-w-4xl mx-auto mb-32">
          <div className="glass-card p-4 rounded-[3.5rem] border-blue-500/20">
            <form onSubmit={handleSubmit} className="flex flex-col md:flex-row gap-4">
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="How are you feeling? (e.g. 'bad headache')"
                className="flex-grow px-10 py-7 rounded-[2.5rem] text-white startup-input focus:outline-none text-xl font-bold placeholder:text-slate-600"
                required
              />
              <button
                type="submit"
                disabled={loading}
                className="px-14 py-7 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-black rounded-[2.5rem] text-xl transition-all shadow-2xl shadow-blue-600/30"
              >
                {loading ? 'Analyzing...' : 'Start Now'}
              </button>
            </form>
          </div>
          <p className="text-center mt-6 text-[10px] font-black text-slate-500 uppercase tracking-[0.3em]">
            Powered by MadiPath AI Core • Secure & Private
          </p>
        </div>

        {error && (
          <div className="max-w-3xl mx-auto glass-card p-10 rounded-[3rem] border-red-500/20 mb-20 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-2 h-full bg-red-600"></div>
            <div className="flex items-center space-x-8">
              <div className="w-14 h-14 bg-red-600/10 rounded-2xl flex items-center justify-center shrink-0">
                <span className="text-red-500 font-black text-2xl">!</span>
              </div>
              <div>
                <h4 className="text-red-500 font-black uppercase tracking-widest text-sm mb-2">Safety Alert</h4>
                <p className="text-slate-300 font-bold">{error}</p>
              </div>
            </div>
          </div>
        )}

        {result && <AnalysisResult data={result} />}

        {!result && !loading && !error && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { icon: "🚑", title: "Emergency Detection", desc: "Instantly identifies life-threatening patterns." },
              { icon: "💊", title: "OTC Guidance", desc: "Safe supportive care suggestions for mild cases." },
              { icon: "👩‍⚕️", title: "Protocol Driven", desc: "Based on international clinical triage standards." }
            ].map((f, i) => (
              <div key={i} className="glass-card p-10 rounded-[3rem] hover:border-blue-500/30 transition-all group">
                <div className="text-4xl mb-6 group-hover:scale-110 transition-transform">{f.icon}</div>
                <h5 className="text-white font-black uppercase tracking-tighter text-lg mb-4">{f.title}</h5>
                <p className="text-slate-500 font-bold text-sm leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
};

export default App;
